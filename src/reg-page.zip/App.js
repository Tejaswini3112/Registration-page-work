import Navbar from "./components/Navbar";
import Regform from "./components/Regform"
import './App.css';
import Footer from "./components/Footer";

function App() {
  return (
    <div className="App">
     <Navbar></Navbar>
     <Regform></Regform>
    <Footer></Footer>
    </div>
  );
}

export default App;
