import React from 'react'

function footer() {
  return (
    <div className="block bg-black text-white mx-auto ">


        <div className="flex h-28">

            <div className="p-5  m-auto">

                <a href="/">Terms & Conditions Privacy Policy</a>
                &copy;
            </div>
            <div className=" text-right m-auto">
                <a href="/">Follow us</a>
                
            </div>
        </div>
    </div>
  )
}

export default footer