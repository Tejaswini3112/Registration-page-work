import './App.css';
import Comp from './COMP/Comp';
import Header from './COMP/Header';
import Footer from './COMP/footer'

function App() {
  return (
    <div className="App">
    <Header/>
     <Comp ></Comp>
     <Footer/>
    </div>
  );
}

export default App;
